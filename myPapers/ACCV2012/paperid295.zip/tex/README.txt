
To make a sample ECCV paper, copy the contents of this directory
somewhere, and type

 latex eccv2012ws-submission
 bibtex eccv2012ws-submission
 latex eccv2012ws-submission
 latex eccv2012ws-submission

or 

 pdflatex eccv2012ws-submission
 bibtex eccv2012ws-submission
 pdflatex eccv2012ws-submission
 pdflatex eccv2012ws-submission
